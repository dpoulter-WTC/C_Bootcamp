ifconfig | grep 'ether ' | tr -d '[:blank:]'
